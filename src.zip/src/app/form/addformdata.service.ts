import { EventEmitter } from '@angular/core' 
import { FormData } from './formdata.model';

export class AddFormDataService{
    datasChanged = new EventEmitter<FormData[]>();
    private datas: FormData[] = [
        new FormData('Cell Phone Store', 'cps@gmail.com', 'Sony Mobiles, Nokia, BlackBerry, Motorola, Lenovo & Accessories', 'Goodluck Chowk, Pune')
        ];
 getFormData(){
 return this.datas.slice();
 }
 addFormData(data: FormData){
     this.datas.push(data);
     this.datasChanged.emit(this.datas.slice());
 }

addFormDatas(datas: FormData[]){
    
    this.datas.push(...datas);
    this.datasChanged.emit(this.datas.slice());
  }

 }