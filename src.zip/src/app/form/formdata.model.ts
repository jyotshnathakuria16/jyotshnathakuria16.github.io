export class FormData{
    constructor(public storeName:string,  public storeEmail:string, public storeDescription:string, public location:string ){}
    }