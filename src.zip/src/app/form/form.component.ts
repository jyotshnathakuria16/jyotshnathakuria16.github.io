import { Component, OnInit, ElementRef, ViewChild, EventEmitter } from '@angular/core';
import {NgForm, FormGroup, FormControl, Validators} from '@angular/forms';

import { FormData } from './formdata.model';
import{ AddFormDataService } from './addformdata.service'

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  @ViewChild('name') nameRef: ElementRef;
  @ViewChild('email') emailRef: ElementRef;
  @ViewChild('des') desRef: ElementRef;
  @ViewChild('loc') locRef: ElementRef;

  formDataAdded =new EventEmitter<FormData>();
  
    constructor(private slService: AddFormDataService) { }
  
    ngOnInit() {
    }
  
 
    onSubmit(form: NgForm)
{
  const fname = this.nameRef.nativeElement.value;
  const femail = this.emailRef.nativeElement.value;
  const fdes = this.desRef.nativeElement.value;
  const floc = this.locRef.nativeElement.value;

  const newFormData = new FormData(fname, femail, fdes, floc)
  this.slService.addFormData(newFormData)

}

  
}
