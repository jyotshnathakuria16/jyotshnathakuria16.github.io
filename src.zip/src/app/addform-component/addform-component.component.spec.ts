import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddformComponentComponent } from './addform-component.component';

describe('AddformComponentComponent', () => {
  let component: AddformComponentComponent;
  let fixture: ComponentFixture<AddformComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddformComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddformComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
