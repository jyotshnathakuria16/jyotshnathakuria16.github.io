import { Component, OnInit } from '@angular/core';
import { FormData } from '../form/formdata.model';
import { AddFormDataService } from '../form/addformdata.service'


@Component({
  selector: 'app-addform-component',
  templateUrl: './addform-component.component.html',
  styleUrls: ['./addform-component.component.css']
})
export class AddformComponentComponent implements OnInit {
  formData: FormData[];
  
    constructor(private slService: AddFormDataService) { }
  
    ngOnInit() {
      this.formData= this.slService.getFormData();
      this.slService.datasChanged
      .subscribe(
      (formData: FormData[]) => {
        this.formData= formData;
      }
      );
    } 
  }
  