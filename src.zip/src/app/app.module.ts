import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule} from '@angular/router';

import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { FormGroup, FormControl, Validators} from '@angular/forms';


import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import { TitleCasePipe } from '@angular/common';
import { AddformComponentComponent } from './addform-component/addform-component.component';
import { AddFormDataService } from './form/addformdata.service'



@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    AddformComponentComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [AddFormDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
